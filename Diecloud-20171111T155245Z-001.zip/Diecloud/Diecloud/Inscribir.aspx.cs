﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Diecloud.ServiceReference1;

namespace Diecloud
{
    public partial class Inscribir : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnMostrarAll2_Click(object sender, EventArgs e)

        {
            Seminarios seminario = new Seminarios();
            ServiceDIE1Client cliente2 = new ServiceDIE1Client();

            gvDatos2.DataSource = cliente2.Mostrarseminarios();

            gvDatos2.DataBind();

        }

        protected void Button3_Click(object sender, EventArgs e)

        {
            //Estudiante estudiante = new Estudiante();
            ServiceDIE1Client cliente3 = new ServiceDIE1Client();
            Imparte imparte = new Imparte();

            String codse = TextBox3.Text;
            imparte = cliente3.Buscarsem(codse);

            String g1 = Convert.ToString(imparte.Cod_s);
            TextBox4.Text = g1;

            String g2 = Convert.ToString(imparte.Id_p);
            TextBox5.Text = g2;

            String g3 = Convert.ToString(imparte.Grupo);
            TextBox6.Text = g3;

            String g4 = Convert.ToString(imparte.Horario);
            TextBox7.Text = g4;



        }


        protected void Button2_Click(object sender, EventArgs e)

        {
            //Estudiante estudiante = new Estudiante();
            ServiceDIE1Client cliente4 = new ServiceDIE1Client();
            Imparte imparte = new Imparte();

            imparte.Cod_s = Convert.ToInt64(TextBox5.Text);
            imparte.Id_p = Convert.ToInt64(TextBox4.Text);
            imparte.Grupo = Convert.ToInt16(TextBox6.Text);
            imparte.Horario = TextBox7.Text;
            string id = TextBox2.Text;

            cliente4.Nuevainscripcion(imparte, id);

            if (cliente4.Nuevainscripcion(imparte, id) > 0)
            {
                lbMesaje.Text = "Seminario inscrito";
            }


        }







    }



}
