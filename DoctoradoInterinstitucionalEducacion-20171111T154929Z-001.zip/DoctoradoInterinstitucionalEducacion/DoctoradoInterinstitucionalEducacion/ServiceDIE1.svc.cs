﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;
using System.ServiceModel.Web;
using System.Data.Entity.Core.EntityClient;

namespace DoctoradoInterinstitucionalEducacion
{
    public class ServiceDIE1 : IServiceDIE1
    {
        public string cadena = ConfigurationManager.ConnectionStrings["DoctoradoEntities2"].ConnectionString;

      

        public Imparte Buscarsem(string cods)
        {
            string uno = ConfigurationManager.ConnectionStrings["DoctoradoEntities3"].ConnectionString;
            SqlConnection sql = new SqlConnection();
            sql.ConnectionString = uno;
             long codsem = Convert.ToInt64(cods);
            Imparte newimparte = new Imparte();
             SqlCommand cmd = new SqlCommand();
            List<Imparte> lista3 = new List<Imparte>();
            try
            {
                using (sql)
                {
                    sql.Open();
                    
                    cmd = new SqlCommand("select * from imparte where cod_s=@cods", sql);
                    cmd.Parameters.AddWithValue("@cods", cods);
                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.HasRows)
                    {
                        if (rd.Read()) {
                            newimparte.Cod_s = rd.GetInt64(0);
                            newimparte.Id_p = rd.GetInt64(1);
                            newimparte.Grupo = rd.GetInt16(2);
                            newimparte.Horario = rd.GetString(3);


                        }

                    }

                    else
                    {
                        throw new Exception("no hay registros");
                    }
                }
                sql.Close();

            }
            
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
            return newimparte;
}







        int IServiceDIE1.Buscarestudiante(Estudiante estudiante)
        {
            throw new NotImplementedException();
        }


        int IServiceDIE1.Editarestudiante(Estudiante estudiante)
        {
            throw new NotImplementedException();
        }

        int IServiceDIE1.Eliminarestudiante(Estudiante estudiante)
        {
            throw new NotImplementedException();
        }

        List<Imparte> IServiceDIE1.Mostrardatossem()
        {
            throw new NotImplementedException();
        }

        public List<Estudiante> Mostrarestudiante()
        {
           string uno = ConfigurationManager.ConnectionStrings["DoctoradoEntities3"].ConnectionString;
            SqlConnection sql = new SqlConnection();
            sql.ConnectionString = uno;
            //sqlConnection.ConnectionString= uno;
            //DataTable dt = new DataTable();
            Estudiante newestudiante = new Estudiante();

            // EntityConnection connection = new EntityConnection(uno);
            DataSet ds = new DataSet();
            List<Estudiante> lista =new List<Estudiante>();
            try
            {
               // SqlConnection Model = new SqlConnection(uno);
                
                using (sql)
                {
                    sql.Open();
                    SqlDataAdapter da = new SqlDataAdapter("select * from estudiantes", sql);
                    SqlCommand cmd = new SqlCommand("select * from estudiantes", sql);
                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.HasRows)
                    {
                       
                        while(rd.Read())
                      {
                          lista.Add(new Estudiante { 
                            Cod_e = rd.GetInt64(0),
                           Nom_e = rd.GetString(1),
                            Dir_e = rd.GetString(2),
                            Tel_e = rd.GetInt64(3),
                            Id_e = rd.GetInt64(4),
                          Contraseña_e = rd.GetString(5)
                            });
                        }

                }
                    else
                    {
                        throw new Exception("no hay registros");
                    }

                    sql.Close();

                    

                    //EntityCommand da = new EntityCommand("select * from estudiantes",connection);
                    /*da.Fill(ds);
                    var ldatos = new List<Estudiante>();
                    foreach (DataRow s in ds.Tables[0].Rows)
                    {
                        var dt = new Estudiante();
                        dt.Cod_e =  long.Parse(s[0].ToString());
                        dt.Nom_e = s[1].ToString();
                        dt.Dir_e= s[2].ToString();
                        dt.Tel_e= long.Parse(s[3].ToString());
                        dt.Id_e= long.Parse(s[4].ToString());
                        dt.Contraseña_e = s[5].ToString();                       

                    }
                    return ldatos;
                }
                //return ds.Tables[0]. list;*/
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }

            return lista;
        }
                  
            List<Estudiante> IServiceDIE1.Mostrarinscripciones()
        {
            throw new NotImplementedException();
        }


        int IServiceDIE1.Nuevainscripcion(Imparte imparte, String code)
        {
            string uno = ConfigurationManager.ConnectionStrings["DoctoradoEntities3"].ConnectionString;
            SqlConnection sql = new SqlConnection();
            sql.ConnectionString = uno;
            long ides = Convert.ToInt64(code);
           // long codsem = Convert.ToInt64(cods);
            int res = 0;
           // Imparte newimparte = new Imparte();
            List<Imparte> lista3 = new List<Imparte>();
            SqlCommand cmd2 = new SqlCommand();


            try
             {
                
                    sql.Open();
                cmd2 = new SqlCommand("insert into inscribe (cod_e,id_p,cod_s,grupo)values(@cod_e, @id_p, @cod_s,@grupo)", sql);

                         cmd2.Parameters.AddWithValue("@cod_e", ides);
                         cmd2.Parameters.AddWithValue("@id_p",imparte.Id_p);
                         cmd2.Parameters.AddWithValue("@cod_s",imparte.Cod_s);
                         cmd2.Parameters.AddWithValue("@grupo",imparte.Grupo);

                res = cmd2.ExecuteNonQuery();
                
                sql.Close();

                     }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }


            return res;
                
            }



             

                       





        int IServiceDIE1.Nuevoestudiante(Estudiante estudiante)
        {    
                          throw new NotImplementedException();
            
                }

        public List<Seminarios> Mostrarseminarios()
        {
            string uno = ConfigurationManager.ConnectionStrings["DoctoradoEntities3"].ConnectionString;
            SqlConnection sql = new SqlConnection();
            sql.ConnectionString = uno;
            Seminarios newseminarios = new Seminarios();

            List<Seminarios> lista2 = new List<Seminarios>();
            try
            {
                // SqlConnection Model = new SqlConnection(uno);

                using (sql)
                {
                    sql.Open();
                    //SqlDataAdapter da = new SqlDataAdapter("select * from estudiantes", sql);
                    SqlCommand cmd = new SqlCommand("select * from seminarios", sql);
                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.HasRows)
                    {

                        while (rd.Read())
                        {
                            lista2.Add(new Seminarios
                            {
                                Cod_s = rd.GetInt64(0),
                                Nom_s = rd.GetString(1),
                                Ih = rd.GetInt16(2),
                                Cred = rd.GetInt16(3)
                        });
                        }

                    }
                    else
                    {
                        throw new Exception("no hay registros");
                    }

                    sql.Close();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }

            return lista2;
        }
    }
}
