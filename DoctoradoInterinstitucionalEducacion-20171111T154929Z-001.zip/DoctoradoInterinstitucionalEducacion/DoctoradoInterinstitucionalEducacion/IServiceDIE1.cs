﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DoctoradoInterinstitucionalEducacion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceDIE1" en el código y en el archivo de configuración a la vez.

    [ServiceContract]
    public interface IServiceDIE1
    {
        [OperationContract]
        int Nuevoestudiante(Estudiante estudiante);
        [OperationContract]
        int Editarestudiante(Estudiante estudiante);
        [OperationContract]
        int Eliminarestudiante(Estudiante estudiante);
        [OperationContract]
        int Buscarestudiante(Estudiante estudiante);

        [OperationContract]
        Imparte Buscarsem(String cods);

        [OperationContract]
        List<Estudiante> Mostrarestudiante();
        
        [OperationContract]
        int Nuevainscripcion(Imparte imparte,string code);

      

        [OperationContract]
        List<Estudiante> Mostrarinscripciones();
        [OperationContract]
        List<Imparte> Mostrardatossem();
        [OperationContract]
        List<Seminarios> Mostrarseminarios();


    }

    [DataContract]
    public class Estudiante
    {
        long cod_e;
        String nom_e;
        String dir_e;
        long tel_e;
        long id_e;
        String contraseña_e;

        [DataMember]
        public long Cod_e { get; set; }
        [DataMember]
        public string Nom_e { get; set; }
        [DataMember]
        public string Dir_e { get ; set; }
            [DataMember]
        public long Tel_e { get; set; }
             [DataMember]
        public long Id_e { get; set; }
        [DataMember]
        public string Contraseña_e { get; set; }
    }
    [DataContract]
    public class Incribir
    {
        long cod_e;
        long id_p;
        long cod_s;
        short grupo;

        [DataMember]
        public long Cod_e { get; set; }
    
        [DataMember]
        public long Id_p { get; set; }
        [DataMember]
        public long Cod_s { get; set; }
        [DataMember]
        public short Grupo { get; set; }
    }
    [DataContract]

    public class Seminarios
    {
        long cod_s;
        string nom_s;
        short ih;
        short cred;

        [DataMember]
        public long Cod_s { get; set; }

        [DataMember]
        public string Nom_s { get; set; }
        [DataMember]
        public short Ih { get; set; }
        
        [DataMember]
        public short Cred { get; set; }
      
    }

    [DataContract]
    public class Imparte
    {
        long id_p=1000;
        long cod_s;
        short grupo;
        string horario;

        [DataMember]
        public long Id_p { get; set; }

        [DataMember]
        public long Cod_s { get; set; }

        [DataMember]
        public short Grupo { get; set; }

        [DataMember]
        public string Horario { get; set; }

    }



 }